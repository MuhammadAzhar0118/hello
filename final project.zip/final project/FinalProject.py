#!/usr/bin/env python
# coding: utf-8

# # FinalProject
# 
# 

# In[2]:


import numpy as np
from PIL import  Image
import os, cv2

# Method to train custom classifier to recognize face



import cv2

faceCascade=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
def dataset(img,userid,imageID):
    cv2.imwrite("data/user."+str(userid)+"."+str(imageID)+".jpg",img)
    
def detect(img,faceCascade,imgID,userid):
    gray_img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    
    features=faceCascade.detectMultiScale(gray_img,1.2,10)
    coords=[]
    for (x,y,w,h) in features:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
    
        coords=[x,y,w,h]
    if len(coords)==4:
        rimg=img[coords[1]:coords[1]+coords[3],coords[0]:coords[0]+coords[2]]
        dataset(rimg,userid,imgID)    
    return img



def train_classifer(data_dir):
    # Read all the images in custom data-set
    path = [os.path.join(data_dir, f) for f in os.listdir(data_dir)]
    faces = []
    ids = []

    # Store images in a numpy format and ids of the user on the same index in imageNp and id lists
    for image in path:
        img = Image.open(image).convert('L')
        imageNp = np.array(img, 'uint8')
        idd = int(os.path.split(image)[1].split(".")[1])

        faces.append(imageNp)
        ids.append(idd)

    ids = np.array(ids)
    print(ids)
    # Train and save classifier
    
    clf = cv2.face.LBPHFaceRecognizer_create()
    clf.train(faces,ids)

    clf.write("classifier.xml")

    
import cv2

faceCascade=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

clf= cv2.face.LBPHFaceRecognizer_create()
clf.read("classifier.xml")

def draw(img,classifier,scaleFactor,minNeighbors,color ,clf):
    gra_img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    features=classifier.detectMultiScale(gra_img,scaleFactor,minNeighbors)
    coords=[]
    for (x,y,w,h) in features:
        cv2.rectangle(img,(x,y),(x+w,y+h),color,2)
        idd,_=clf.predict(gra_img[y:y+w,x:x+h])
        for k in range(len(names)):
            if idd == k:
                cv2.putText(img,names[idd],(x,y-4),cv2.FONT_HERSHEY_SIMPLEX,0.8,color,1,cv2.LINE_AA)   
        
        coords=[x,y,w,h]
    return coords   
def recognize(img,clf,faceCascade):
    coords= draw(img,faceCascade,1.1,10,(0,255,0),clf)
    
    return img



names=[]    
print("press_1 for adding more faces press_2 for recognizer")
num=int(input())

if num==2:
    video=cv2.VideoCapture(0)
    file = open("Names.txt","r")
    for n in file.readlines():
        names.append(n)
    names="\n".join(names).split()
    file.close()
    print(names)
    while True:

        check,img=video.read()


        img=recognize(img,clf,faceCascade)
        cv2.imshow("image",img)

        if cv2.waitKey(1)&0xFF==ord('q'):
            break
    cv2.destroyAllWindows()        
if num==1:
    print("enter user name ")
    
    file=open("Names.txt","a")
    name=input()
    
    file.writelines(name)
    file.close()
    video=cv2.VideoCapture(0)
    file1=open("userID.txt","r")
    ind=file1.read()
    file1.close()
    
    imgID=0
    while True:

        check,img=video.read()

        img=detect(img,faceCascade,imgID,ind)

        cv2.imshow("image",img)
        
        
        imgID+=1
        
        
        if  cv2.waitKey(1)&0xFF==ord('q') or imgID==30:
            break
    ind=int(ind)+1
    file2=open("userID.txt","w")
    file2.write(str(ind))
    file2.close()
    cv2.destroyAllWindows()        
    train_classifer("data")
    ind+=1


# In[33]:


file = open("TEMP.txt","r")
names=[]
for n in file.readlines():
    names.append(n)
names="\n".join(names).split()

print(name)
file.close()

